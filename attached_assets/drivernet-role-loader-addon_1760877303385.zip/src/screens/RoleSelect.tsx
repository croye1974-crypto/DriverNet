
import { useNavigate } from "react-router-dom";

export default function RoleSelect() {
  const nav = useNavigate();
  const setRole = async (role: "driver" | "loader") => {
    const userId = localStorage.getItem("uid");
    if (!userId) {
      // In a real app, create or fetch the user first.
      localStorage.setItem("uid", String(Math.floor(Math.random() * 1e9)));
    }
    await fetch("/api/roles/set-role", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: localStorage.getItem("uid"), role })
    });
    localStorage.setItem("role", role);
    nav(role === "driver" ? "/driver" : "/loader");
  };

  return (
    <div style={{ padding: 24 }}>
      <h2>Choose how you want to use DriverNet</h2>
      <p>You can switch any time in settings.</p>
      <div style={{ display: "grid", gap: 12, maxWidth: 420 }}>
        <button onClick={() => setRole("driver")}>I am an individual driver</button>
        <button onClick={() => setRole("loader")}>I operate a low-loader or flatbed</button>
      </div>
    </div>
  );
}


import { useEffect, useState } from "react";

type LoaderSpace = {
  id?: number;
  capacityKg?: number;
  lengthCm?: number;
  widthCm?: number;
  heightCm?: number;
  acceptsCars?: boolean;
  acceptsVans?: boolean;
  acceptsBikes?: boolean;
  acceptsNonRunners?: boolean;
  strapsAvailable?: boolean;
  winchAvailable?: boolean;
  originW3W?: string;
  destW3W?: string;
  departAfter?: string;
  arriveBefore?: string;
  note?: string;
};

export default function LoaderHome() {
  const [avail, setAvail] = useState<LoaderSpace[]>([]);
  const [form, setForm] = useState<LoaderSpace>({ acceptsCars: true, strapsAvailable: true });

  useEffect(() => {
    fetch("/api/loader-spaces/available").then(r => r.json()).then(setAvail);
  }, []);

  const postSpace = async () => {
    const userId = Number(localStorage.getItem("uid") || 0);
    const payload = { userId, status: "available", ...form };
    await fetch("/api/loader-spaces", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const next = await fetch("/api/loader-spaces/available").then(r => r.json());
    setAvail(next);
  };

  const checkIn = async () => {
    const userId = Number(localStorage.getItem("uid") || 0);
    const now = new Date();
    const in2h = new Date(Date.now() + 2 * 60 * 60 * 1000);
    await fetch("/api/checkins", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId, role: "loader",
        lat: null, lng: null, w3w: (form.originW3W || ""),
        fromTime: now.toISOString(), toTime: in2h.toISOString(),
        note: "Low-loader available"
      })
    });
    alert("Checked in");
  };

  return (
    <div style={{ padding: 16 }}>
      <h2>Low-Loader dashboard</h2>

      <section style={{ marginBottom: 24 }}>
        <h3>Quick actions</h3>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button onClick={checkIn}>Check in for the next 2 hours</button>
          <button onClick={postSpace}>Post current space</button>
        </div>
      </section>

      <section style={{ marginBottom: 24 }}>
        <h3>Advertise space</h3>
        <div style={{ display: "grid", gap: 8, maxWidth: 640 }}>
          <input placeholder="Capacity kg" type="number"
            onChange={e => setForm({ ...form, capacityKg: Number(e.target.value) })} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
            <input placeholder="Length cm" type="number" onChange={e => setForm({ ...form, lengthCm: Number(e.target.value) })} />
            <input placeholder="Width cm" type="number" onChange={e => setForm({ ...form, widthCm: Number(e.target.value) })} />
            <input placeholder="Height cm" type="number" onChange={e => setForm({ ...form, heightCm: Number(e.target.value) })} />
          </div>

          <label><input type="checkbox" defaultChecked onChange={e => setForm({ ...form, acceptsCars: e.target.checked })} /> Cars</label>
          <label><input type="checkbox" onChange={e => setForm({ ...form, acceptsVans: e.target.checked })} /> Vans</label>
          <label><input type="checkbox" onChange={e => setForm({ ...form, acceptsBikes: e.target.checked })} /> Motorbikes</label>
          <label><input type="checkbox" onChange={e => setForm({ ...form, acceptsNonRunners: e.target.checked })} /> Non-runners</label>
          <label><input type="checkbox" defaultChecked onChange={e => setForm({ ...form, strapsAvailable: e.target.checked })} /> Straps available</label>
          <label><input type="checkbox" onChange={e => setForm({ ...form, winchAvailable: e.target.checked })} /> Winch available</label>

          <input placeholder="Origin what3words" onChange={e => setForm({ ...form, originW3W: e.target.value })} />
          <input placeholder="Destination what3words" onChange={e => setForm({ ...form, destW3W: e.target.value })} />

          <label>Depart after
            <input type="datetime-local" onChange={e => setForm({ ...form, departAfter: e.target.value })} />
          </label>
          <label>Arrive before
            <input type="datetime-local" onChange={e => setForm({ ...form, arriveBefore: e.target.value })} />
          </label>

          <textarea placeholder="Notes for drivers" onChange={e => setForm({ ...form, note: e.target.value })} />
        </div>
      </section>

      <section>
        <h3>Available space near you</h3>
        <ul>
          {avail.map((s, idx) => (
            <li key={s.id ?? idx}>
              {s.originW3W} → {s.destW3W} | {s.capacityKg ?? "n/a"} kg | cars {s.acceptsCars ? "yes" : "no"} | non-runners {s.acceptsNonRunners ? "yes" : "no"}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}


import { Link, useNavigate } from "react-router-dom";

export default function AppHeader() {
  const nav = useNavigate();
  const switchRole = () => {
    const current = localStorage.getItem("role") === "loader" ? "driver" : "loader";
    localStorage.setItem("role", current);
    nav(current === "driver" ? "/driver" : "/loader");
  };
  return (
    <header style={{ padding: 12, borderBottom: "1px solid #ddd" }}>
      <Link to="/driver" style={{ marginRight: 12 }}>Driver</Link>
      <Link to="/loader" style={{ marginRight: 12 }}>Low-Loader</Link>
      <button onClick={switchRole}>Switch role</button>
    </header>
  );
}

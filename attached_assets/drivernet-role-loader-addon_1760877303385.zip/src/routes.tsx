
import { createBrowserRouter } from "react-router-dom";
import RoleSelect from "./screens/RoleSelect";
// You must already have DriverHome. If it is named differently, adjust the import.
// Placeholder import commented out to avoid compile error.
// import DriverHome from "./screens/DriverHome";
import LoaderHome from "./screens/LoaderHome";

const DummyDriver = () => <div style={{ padding: 24 }}><h2>Driver Home</h2><p>Hook this to your existing driver UI.</p></div>;

export const router = createBrowserRouter([
  { path: "/", element: <RoleSelect /> },
  { path: "/driver", element: <DummyDriver /> }, // replace with <DriverHome />
  { path: "/loader", element: <LoaderHome /> }
]);

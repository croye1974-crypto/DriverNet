
import fetch from "node-fetch";
const W3W_KEY = process.env.W3W_API_KEY;

export async function w3wToCoords(words: string) {
  if (!W3W_KEY) return null;
  const r = await fetch(`https://api.what3words.com/v3/convert-to-coordinates?words=${encodeURIComponent(words)}&key=${W3W_KEY}`);
  if (!r.ok) return null;
  const j = await r.json();
  return j.coordinates ? { lat: j.coordinates.lat, lng: j.coordinates.lng } : null;
}

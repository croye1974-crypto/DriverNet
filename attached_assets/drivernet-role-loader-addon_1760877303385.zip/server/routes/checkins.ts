
import { Router } from "express";
import { db } from "../db";
import { checkins } from "../db/schema";

const r = Router();

r.post("/", async (req, res) => {
  const { userId, role, lat, lng, w3w, fromTime, toTime, note } = req.body;
  if (!userId || !role || !fromTime || !toTime) {
    return res.status(400).json({ error: "Missing fields" });
  }
  const row = await db.insert(checkins).values({
    userId: Number(userId), role, lat, lng, w3w,
    fromTime: new Date(fromTime), toTime: new Date(toTime), note
  }).returning();
  res.json(row[0]);
});

r.get("/nearby", async (_req, res) => {
  // Replace with geo + time window filtering later.
  // @ts-ignore drizzle query helper depends on your setup.
  const rows = await db.query.checkins.findMany({ limit: 100 });
  res.json(rows);
});

export default r;


import { Router } from "express";
import { db } from "../db";
import { loaderSpaces } from "../db/schema";

const r = Router();

r.post("/", async (req, res) => {
  const payload = req.body;
  if (!payload.userId) return res.status(400).json({ error: "Missing userId" });
  const row = await db.insert(loaderSpaces).values({
    ...payload,
    userId: Number(payload.userId),
    departAfter: payload.departAfter ? new Date(payload.departAfter) : null,
    arriveBefore: payload.arriveBefore ? new Date(payload.arriveBefore) : null
  }).returning();
  res.json(row[0]);
});

r.get("/available", async (_req, res) => {
  // @ts-ignore drizzle query helper depends on your setup.
  const rows = await db.query.loaderSpaces.findMany({ limit: 100 });
  res.json(rows);
});

export default r;


import { Router } from "express";
import { db } from "../db";
import { users } from "../db/schema";
import { eq } from "drizzle-orm";

const r = Router();

r.post("/set-role", async (req, res) => {
  const { userId, role } = req.body;
  if (!["driver","loader"].includes(role)) return res.status(400).json({ error: "Bad role" });
  const uid = Number(userId);
  if (!uid) return res.status(400).json({ error: "No userId" });
  await db.update(users).set({ role }).where(eq(users.id, uid));
  res.json({ ok: true });
});

export default r;


DriverNet Role Selector + Low-Loader Add-on
===========================================
Drop-in files for a Vite + React + Express + Drizzle/Neon project.

What this adds
--------------
1) Role selection screen: Driver or Low-Loader
2) Loader dashboard with:
   - Quick check in
   - Post available space with capacity and constraints
   - List of available space
3) API routes for roles, checkins, and loaderSpaces
4) Drizzle schema for users, checkins, and loader_spaces
5) Optional What3Words helper

How to install
--------------
1) Copy the folders into your project root. Do not overwrite your existing files unless you intend to.
2) Ensure your server mounts the routes in server/index.ts:
     app.use(express.json());
     app.use("/api/roles", roles);
     app.use("/api/checkins", checkins);
     app.use("/api/loader-spaces", loaderSpaces);

3) Add routes to your React router (src/routes.tsx). If you already have a router, merge the routes.
   New paths:
     /            -> RoleSelect
     /driver      -> DriverHome (your existing screen)
     /loader      -> LoaderHome (new screen)

4) Environment variables:
     DATABASE_URL=postgres://...
     W3W_API_KEY=your_key_if_using

5) Build and run as normal:
     npm run build
     npm run start

Notes
-----
- If you use ESM in server code, keep the import syntax as provided.
- If you use CJS, convert imports to require() accordingly.
- Add real auth and geo filtering later. The current nearby endpoint returns recent entries.


import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("driver"),
  createdAt: timestamp("created_at").defaultNow()
});

export const checkins = pgTable("checkins", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  role: text("role").notNull(),
  lat: text("lat"),
  lng: text("lng"),
  w3w: text("w3w"),
  fromTime: timestamp("from_time").notNull(),
  toTime: timestamp("to_time").notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow()
});

export const loaderSpaces = pgTable("loader_spaces", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  status: text("status").notNull().default("available"),
  capacityKg: integer("capacity_kg"),
  lengthCm: integer("length_cm"),
  widthCm: integer("width_cm"),
  heightCm: integer("height_cm"),
  acceptsCars: boolean("accepts_cars").default(true),
  acceptsVans: boolean("accepts_vans").default(false),
  acceptsBikes: boolean("accepts_bikes").default(false),
  acceptsNonRunners: boolean("accepts_nonrunners").default(false),
  strapsAvailable: boolean("straps_available").default(true),
  winchAvailable: boolean("winch_available").default(false),
  originLat: text("origin_lat"),
  originLng: text("origin_lng"),
  originW3W: text("origin_w3w"),
  destLat: text("dest_lat"),
  destLng: text("dest_lng"),
  destW3W: text("dest_w3w"),
  departAfter: timestamp("depart_after"),
  arriveBefore: timestamp("arrive_before"),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow()
});

# DriveNet MVP (Unified roles + global Offer Lift)

This is a minimal full stack project that you can run in Replit with one import. It gives you:
- One UI with modes: Driver, Low Loader, Lift Seeker, Business
- Global “Offer lift between jobs”
- Simple Express API with in memory storage
- Basic matching endpoint for lifts and loads

## Run
1. Create a new Replit from GitHub or ZIP import, or upload these files.
2. Open the shell and run: `npm install`
3. Start: `npm start`
4. Open the web view. You should see the app.

## Files
- `server.js` Express server and API
- `public/index.html` React single page app wired to the API
- `package.json` dependencies and start script

## Notes
- Storage is in memory. It resets on restart.
- Endpoints: `/api/liftOffers`, `/api/driverAvailability`, `/api/capacityOffers`, `/api/liftRequests`, `/api/loadRequests`, `/api/matches`
- This is an MVP for testing. Swap to a database later.

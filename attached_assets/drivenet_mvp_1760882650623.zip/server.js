// Simple DriveNet MVP server: static hosting + in‑memory API
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { nanoid } = require('nanoid');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());

// In‑memory store
const db = {
  users: [],
  liftOffers: [],           // seats in cars
  driverAvailability: [],   // planned legs
  capacityOffers: [],       // low loader capacity
  liftRequests: [],         // riders
  loadRequests: [],         // business shipments
  matches: []               // cached matches
};

// Helpers
function nowISO(){ return new Date().toISOString(); }
function id(prefix){ return `${prefix}_${nanoid(10)}`; }

// Route overlap score (very rough): if from and to text share any words
function overlapScore(aFrom, aTo, bFrom, bTo){
  const toSet = s => new Set(String(s||"").toLowerCase().split(/[^a-z0-9]+/).filter(Boolean));
  const af = toSet(aFrom), at = toSet(aTo), bf = toSet(bFrom), bt = toSet(bTo);
  let score = 0;
  af.forEach(w => { if (bf.has(w) || bt.has(w)) score += 10; });
  at.forEach(w => { if (bf.has(w) || bt.has(w)) score += 10; });
  return score;
}

// Time window intersection flag
function timeIntersect(aStart, aEnd, bStart, bEnd){
  if(!aStart || !aEnd || !bStart || !bEnd) return true; // be permissive in MVP
  const A1 = new Date(aStart).getTime();
  const A2 = new Date(aEnd).getTime();
  const B1 = new Date(bStart).getTime();
  const B2 = new Date(bEnd).getTime();
  return Math.max(A1,B1) <= Math.min(A2,B2);
}

// Generic CRUD maker
function makeCrud(name){
  const coll = db[name];
  const base = `/api/${name}`;
  app.get(base, (req,res)=> res.json(coll));
  app.post(base, (req,res)=>{
    const item = { id: id(name.slice(0,3)), createdAt: nowISO(), ...req.body };
    coll.push(item);
    res.json(item);
  });
  app.get(`${base}/:id`, (req,res)=>{
    const item = coll.find(x=>x.id===req.params.id);
    if(!item) return res.status(404).json({error:"Not found"});
    res.json(item);
  });
  app.put(`${base}/:id`, (req,res)=>{
    const idx = coll.findIndex(x=>x.id===req.params.id);
    if(idx===-1) return res.status(404).json({error:"Not found"});
    coll[idx] = { ...coll[idx], ...req.body, updatedAt: nowISO() };
    res.json(coll[idx]);
  });
  app.delete(`${base}/:id`, (req,res)=>{
    const idx = coll.findIndex(x=>x.id===req.params.id);
    if(idx===-1) return res.status(404).json({error:"Not found"});
    const [removed] = coll.splice(idx,1);
    res.json(removed);
  });
}

// Create CRUD endpoints
['liftOffers','driverAvailability','capacityOffers','liftRequests','loadRequests'].forEach(makeCrud);

// Match endpoint: compute suggestions both for lifts and loads
app.get('/api/matches', (req,res)=>{
  const out = [];

  // Lift matches: liftOffers vs liftRequests
  db.liftOffers.forEach(offer=>{
    db.liftRequests.forEach(reqItem=>{
      if (offer.seats && offer.seats < (reqItem.seatsNeeded||1)) return;
      if(!timeIntersect(offer.windowStart, offer.windowEnd, reqItem.windowStart, reqItem.windowEnd)) return;
      const score = overlapScore(offer.from, offer.to, reqItem.from, reqItem.to) + 50;
      if(score > 50){
        out.push({
          type:'lift',
          score,
          offerId: offer.id,
          requestId: reqItem.id,
          summary: `${offer.from} → ${offer.to}`
        });
      }
    });
  });

  // Load matches: capacityOffers vs loadRequests
  db.capacityOffers.forEach(cap=>{
    db.loadRequests.forEach(load=>{
      if(cap.maxWeight && load.weight && load.weight > cap.maxWeight) return;
      if(!timeIntersect(cap.date||cap.windowStart, cap.date||cap.windowEnd, load.pickupWindow, load.deliveryWindow)) return;
      const score = overlapScore(cap.from, cap.to, load.pickupAddress, load.dropoffAddress) + 40;
      if(score > 40){
        out.push({
          type:'load',
          score,
          capacityId: cap.id,
          loadId: load.id,
          summary: `${cap.from} → ${cap.to}`
        });
      }
    });
  });

  // Sort high to low
  out.sort((a,b)=> b.score - a.score);
  res.json(out);
});

// Seed a tiny dataset for demo
(function seed(){
  if(db.liftOffers.length) return;
  db.liftOffers.push({
    id: id('lof'), createdAt: nowISO(),
    from: 'A12 Services', to: 'Heathrow',
    windowStart: nowISO(), windowEnd: new Date(Date.now()+2*3600000).toISOString(),
    seats: 1, detourKm: 10, priceType: 'Free'
  });
  db.capacityOffers.push({
    id: id('cap'), createdAt: nowISO(),
    from: 'Derby', to: 'Bristol', date: new Date(Date.now()+4*3600000).toISOString(),
    lengthM: 4.2, widthM: 1.9, heightM: 1.6, maxWeight: 1800, spacePercent: 50, itemsAllowed: ['Running']
  });
})();

// Static hosting
app.use(express.static(path.join(__dirname,'public')));
app.get('*', (req,res)=>{
  res.sendFile(path.join(__dirname,'public','index.html'));
});

app.listen(PORT, ()=> console.log(`DriveNet MVP running on http://localhost:${PORT}`));
